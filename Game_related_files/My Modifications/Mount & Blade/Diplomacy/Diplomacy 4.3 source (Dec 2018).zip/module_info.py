
# Point export_dir to the folder you will be keeping your module
# Make sure you use forward slashes (/) and NOT backward slashes (\)

#export_dir = "E:/Mount&Blade Warband/Modules/Diplomacy/"

#export_dir = "test/"
export_dir = "C:/Program Files (x86)/Mount&Blade Warband/Modules/Diplomacy/"
#export_dir = "../"
