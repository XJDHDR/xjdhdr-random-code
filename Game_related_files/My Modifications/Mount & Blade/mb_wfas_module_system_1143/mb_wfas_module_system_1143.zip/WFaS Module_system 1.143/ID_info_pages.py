ip_morale = 0
ip_economy = 1
ip_politics = 2
ip_military_campaigns = 3


