pfx_default = 0
pfx_map_params = 1
pfx_indoors = 2
pfx_sunset = 3
pfx_night = 4
pfx_sunny = 5
pfx_cloudy = 6
pfx_overcast = 7
pfx_gloomy = 8
pfx_high_contrast = 9


